IRONPEAK TRADING ENTERPRISE CC — WEBSITE V3
Registration number: CC20260645

Included:
index.html — website
style.css — responsive design
script.js — navigation + enquiry form

DONE THIS PHASE:
1. Real contact number added: +264 81 357 7351 (click-to-call + WhatsApp link)
2. Real business email connected: soini644@gmail.com (header/footer/about/quote form)
3. Academy module removed from the Vision section per client request
4. Placeholder imagery added (hero, About, and each Vision card) — these are generic
   royalty-free placeholders (Picsum/Unsplash-licensed), NOT curated brand photography.
   Replace with your own photos/logo before launch.
5. Client Portal front-end preview added (#portal) — login form is visual only and
   does NOT work yet; needs a real auth provider + database + backend to function.
6. Marketplace / Opportunities / Media / Tourism sections marked "Coming soon" as
   front-end scaffolding only — no backend, listings, or bookings behind them yet.
7. Online payment integration was intentionally NOT added (client instruction).

STILL OUTSTANDING:
- Physical/registered address and social media links (not supplied yet — add when ready).
- Real backend for enquiries, CRM, admin dashboard (still out of scope per client instruction).
- Authentication + database to make the Client Portal actually log people in.
- Payment integration — add only when the client is ready to accept online payments.
- Marketplace/Academy-style modules need real data, listings and booking logic.

The registration number shown on the site is the number supplied by the client.
Registration status/good standing should be verified through BIPA before using it
as a public compliance claim.
